package ginsession

import (
	"fmt"
	"github.com/gin-gonic/gin"
	"github.com/satori/go.uuid"
	"sync"
)

// 自己实现的gin框架的session中间件
//Session服务

const (
	SessionCookieName="session_id"  //session_id 在Cookie中对应的名字
	SessionContextName="session"  //session data 在gin上下文中对应的key
)

var (
	//MgrObj 全局的Session管理对象（大仓库）
	MgrObj *Mgr
)

//SessionData 表示一个具体的用户Session数据
type SessionData struct {
	SessionID string
	Data      map[string]interface{}
	rwLock    sync.RWMutex //读写锁，锁的是上面的Data
	//过期时间
}

//NewSessionData 构造函数
func NewSessionData(id string) *SessionData {
	return &SessionData{
		SessionID: id,
		Data:      make(map[string]interface{}, 8),
	}
}

//Mgr 是一个全局的Session管理
type Mgr struct {
	Session map[string]*SessionData
	rwLock  sync.RWMutex
}

//InitMgr Mgr构造函数
func InitMgr(){
	MgrObj=&Mgr{
		Session:make(map[string]*SessionData, 1024), // 初始化1024红色的小框用来存取用户的session data
	}
}

//GetSessionData 根据传进来的SessionID找到对应的SessionData
func (m *Mgr) GetSessionData(sessionID string) (sd *SessionData, err error) {
	//取之前加锁
	m.rwLock.RLock()
	defer m.rwLock.RUnlock()
	sd, ok := m.Session[sessionID]
	if !ok {
		err = fmt.Errorf("invalid session id")
		return
	}
	return
}

//CreateSession 创建一条Session记录
func (m *Mgr) CreateSession() (sd *SessionData) {
	//1.造一个SessionID
	uuidObj,err:= uuid.NewV4()
	if err!=nil{
		panic("create invalid session id")
	}
	//2.造一个和他对应的SessionData
	sd = NewSessionData(uuidObj.String())
	m.Session[sd.SessionID]=sd //把新创建的session data 保存到大仓库中
	//3.返回SessionData
	return
}

//实现一个gin框架的中间件
//所有流经我这个中间件的请求，他的上下文中肯定会有一个Session -> session data
func SessionMiddleware(mgrObj *Mgr)gin.HandlerFunc{
	if mgrObj==nil{
		panic("must call InitMger before use it.")
	}
	//1. 从请求的Cookie中获取SessionID
	//1.1 取不到SessionID,给这个新用户创建一个新的SessionData,同时分配一个SessionID
	//1.2 取SessionID
	//2.  根据sessionid 去Session 大仓库中取到对应的SessionData
	//3.  如何实现让后续所有的处理请求的方法都能拿到sessiondata
	//3.  利用gin 的c.Set("session",sessiondata)
	return func(c *gin.Context){
		//1. 从请求的Cookie中获取SessionID
		var sd *SessionData //session data
		sessionID,err:= c.Cookie(SessionCookieName)
		if err!=nil{
			//1.1 取不到SessionID,给这个新用户创建一个新的SessionData,同时分配一个SessionID
			sd= mgrObj.CreateSession()
			sessionID=sd.SessionID
		}else{
			//1.2 取SessionID
			//2.  根据sessionid 去Session 大仓库中取到对应的SessionData
			sd,err= mgrObj.GetSessionData(sessionID)
			if err!=nil{
				//2.1 根据用户传过来的session_id在大仓库中取不到sessio data
				sd=mgrObj.CreateSession()//sd
				//2.2 更新用户Cookie 中保存的session_id
				sessionID=sd.SessionID
			}
		}
		//3.  如何实现让后续所有的处理请求的方法都能拿到sessiondata
		//3.  利用gin 的c.Set("session",sessiondata)
		c.Set(SessionContextName,sd)
		//在 gin 框架中，要回写Cookie 必须在处理请求的函数返回之前
		c.SetCookie(SessionCookieName,sessionID,3600,"/","127.0.0.1",false,true)
		c.Next() //执行后续的请求处理方法 c.HTML() 时已经把响应头写好了
	}
}

